import os
# 导入操作系统模块，用于处理文件路径和遍历目录。

import xml.etree.ElementTree as ET
# 导入Python内置的XML解析库ElementTree，用于读取和解析XML文件。

import csv
# 导入csv模块，用于读写CSV文件。

def parse_xml(xml_file):
    # 定义一个函数parse_xml，参数为xml_file，表示要解析的XML文件路径。

    tree = ET.parse(xml_file)
    # 使用ElementTree的parse方法读取XML文件，返回一个ElementTree对象。

    root = tree.getroot()
    # 调用getroot()方法获取XML文档的根元素。

    objects = []
    # 初始化一个空列表，用于存储每个XML文件中的所有对象信息。

    for obj in root.findall('object'):
        # 遍历XML文档中所有的<object>标签，每个<object>代表一个识别的对象。

        obj_name = obj.find('name').text
        # 找到当前对象的'name'标签并获取其文本内容，即对象名称。

        bbox = obj.find('bndbox')
        # 找到当前对象的'bndbox'标签，它包含边界框的信息。

        xmin = __________
        ymin = __________
        xmax = __________
        ymax = __________
        # 依次找到'bndbox'下的'xmin', 'ymin', 'xmax', 'ymax'标签，转换为整数类型，存储边界框的坐标。

        objects.append({
            'filename': os.path.splitext(os.path.basename(xml_file))[0],  # 提取文件名（不包括扩展名）
            'name': obj_name,
            'xmin': __________,
            'ymin': __________,
            'xmax': __________,
            'ymax': __________,
        })
        # 依次将xmin,ymin,xmax,ymax以字典形式添加到objects列表中。

    return objects
    # 函数返回存储了所有对象信息的列表。

# Path to the dataset folder containing XML files
data_folder = 'dataset'
# 指定数据集文件夹路径，路径与当前代码同级
output_csv = 'result.csv'
# 指定输出CSV文件的路径，路径与当前代码同级

# List to store all objects across XML files
all_objects = []
# 初始化一个空列表，用于存储所有XML文件中的所有对象信息。

# Iterate over all XML files in the dataset folder
for filename in os.listdir(__________):
    # 遍历数据集文件夹中的所有文件。

    if filename.__________('.xml'):
        # 如果文件是以.xml结尾，则认为是需要解析的XML文件。

        xml_file = os.path.join(data_folder, filename)
        # 使用os.path.join构造完整的XML文件路径。

        objects = parse_xml(xml_file)
        # 调用parse_xml函数，传入XML文件路径，获取该文件中的所有对象信息。

        all_objects.extend(objects)
        # 将当前XML文件中的所有对象信息追加到all_objects列表中。

# Save all_objects to CSV file
with open(output_csv, 'w', newline='') as csvfile:
    # 使用with语句打开CSV文件，'w'模式表示写入，newline=''是为了防止在Windows系统下生成多余的换行符。

    fieldnames = ['filename', 'name', 'xmin', 'ymin', 'xmax', 'ymax']
    # 指定CSV文件的列名。

    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    # 创建一个DictWriter对象，用于将字典写入CSV文件。

    writer.writeheader()
    # 写入CSV文件的头部，即列名。

    for obj in all_objects:
        # 遍历all_objects列表中的每一个字典对象。

        writer.writerow(obj)
        # 将字典对象写入CSV文件中的一行。

print(f"CSV file 'result.csv' saved successfully with {len(all_objects)} objects.")
# 输出成功保存的CSV文件信息，包括文件名和总对象数量。