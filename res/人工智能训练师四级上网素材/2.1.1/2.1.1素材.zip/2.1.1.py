import os

#将目录图片png修改为jpg
data_dir = './2.1.1pic'  # 根据实际情况填写具体文件地址
images = [img for img in os.listdir(data_dir) if img.lower().endswith('.__________')]
for i, old_name in enumerate(images):
    new_name = '{}.jpg'.format(old_name.__________('.')[0])
    os.__________(os.path.join(data_dir, old_name), os.path.join(data_dir, new_name))


#将目录图片已经被修改为“jpg”格式的图片样本以数字编号重命名，数据从“0000”开始计数，顺序累加，如0000.jpg，0001.jpg，0002.jpg….以此类推直至结束
data_dir = './2.1.1pic'  # 根据实际情况填写具体文件地址
images = [img for img in os.listdir(data_dir) if img.lower().endswith('.__________')]
for i, old_name in enumerate(images):
    new_name = '{:04d}.jpg'.format(__________)
    os.__________(os.path.join(data_dir, old_name), os.path.join(data_dir, new_name))